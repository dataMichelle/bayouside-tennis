"use client";

import { createContext, useContext, useState } from "react";
import { loadStripe } from "@stripe/stripe-js";

const PaymentContext = createContext();

export function PaymentProvider({ children }) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState(null);

  const initiatePayment = async (bookingIds, amount, description, userId) => {
    setIsProcessing(true);
    setError(null);
    try {
      const response = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bookingIds,
          amount,
          currency: "USD",
          description,
          userId,
        }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);

      const stripe = await loadStripe(
        process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY
      );
      await stripe.redirectToCheckout({ sessionId: data.sessionId });
    } catch (err) {
      setError(err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const verifyPayments = async (bookingIds) => {
    try {
      const query = bookingIds.map((id) => `bookingId=${id}`).join("&");
      const res = await fetch(`/api/payments?${query}`);
      const data = await res.json();
      const paidIds = Array.isArray(data)
        ? data.map((p) => p.bookingId.toString())
        : [data.bookingId];
      const missingPayments = bookingIds.filter((id) => !paidIds.includes(id));
      return { missingPayments, allVerified: missingPayments.length === 0 };
    } catch (err) {
      console.error("Error verifying payments:", err.message);
      return { missingPayments: bookingIds, allVerified: false };
    }
  };

  return (
    <PaymentContext.Provider
      value={{ initiatePayment, verifyPayments, isProcessing, error }}
    >
      {children}
    </PaymentContext.Provider>
  );
}

export function usePayment() {
  return useContext(PaymentContext);
}
