"use client";

import { useEffect, useState, useCallback } from "react";
import { useSearchParams } from "next/navigation";
import { useUser } from "@/context/UserContext";
import { usePayment } from "@/context/PaymentContext";
import PageContainer from "@/components/PageContainer";
import ReservationCard from "@/components/ReservationCard";

export default function ReservationsPage() {
  const searchParams = useSearchParams();
  const { firebaseUser, userData, loading } = useUser();
  const { initiatePayment, verifyPayments, isProcessing, error } = usePayment();

  const [bookings, setBookings] = useState([]);
  const [fetchError, setFetchError] = useState(null);

  const fetchBookings = useCallback(async () => {
    if (!userData?.id) return;
    try {
      const res = await fetch(
        `/api/player/reservations?playerId=${userData.id}`
      );
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Unknown error");
      setBookings(data.bookings || []);
      setFetchError(null);
    } catch (err) {
      setBookings([]);
      setFetchError(err.message);
    }
  }, [userData?.id]);

  const verifyAndRefresh = useCallback(async () => {
    const success = searchParams.get("success");
    const bookingIds = JSON.parse(searchParams.get("bookingIds") || "[]");

    if (success === "true" && bookingIds.length) {
      const result = await verifyPayments(bookingIds);
      if (result.allVerified) {
        await fetchBookings();
      }
    }
  }, [searchParams, verifyPayments, fetchBookings]);

  useEffect(() => {
    if (firebaseUser && userData?.id) {
      fetchBookings();
      verifyAndRefresh();
    }
  }, [firebaseUser, userData?.id, fetchBookings, verifyAndRefresh]);

  const handlePayNow = async (booking) => {
    try {
      await initiatePayment(
        [booking._id],
        booking.totalCost,
        `Booking for ${new Date(booking.startTime).toLocaleDateString()}`,
        userData?.id
      );
    } catch (err) {
      console.error("Payment initiation failed", err);
    }
  };

  return (
    <PageContainer title="Your Reservations">
      {loading && <p>Loading...</p>}
      {fetchError && <p className="text-red-600">{fetchError}</p>}
      <ul className="space-y-4">
        {bookings.map((booking) => (
          <ReservationCard
            key={booking._id}
            booking={booking}
            onPayNow={handlePayNow}
            isProcessing={isProcessing}
            paymentError={error}
          />
        ))}
      </ul>
    </PageContainer>
  );
}
