"use client";

import { useEffect, useState } from "react";
import PageContainer from "@/components/PageContainer";
import { useUser } from "@/context/UserContext";
import { useRouter } from "next/navigation";

export default function BookingPage() {
  const { firebaseUser, userData, loading } = useUser();
  const router = useRouter();
  const [coaches, setCoaches] = useState([]);
  const [settings, setSettings] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (!firebaseUser && !loading) router.push("/login");
  }, [firebaseUser, loading]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [coachRes, settingsRes] = await Promise.all([
          fetch("/api/coaches"),
          fetch("/api/settings"),
        ]);

        const [coachData, settingsData] = await Promise.all([
          coachRes.json(),
          settingsRes.json(),
        ]);

        setCoaches(coachData);
        setSettings(settingsData);
      } catch (err) {
        setError("Failed to load booking data.");
      }
    };
    fetchData();
  }, []);

  return (
    <PageContainer title="Book Court">
      {error && <p className="text-red-600">{error}</p>}
      {coaches.length > 0 && settings && <p>Render Booking Form Here</p>}
    </PageContainer>
  );
}
