// app/api/stripe/checkout/route.js

import { NextResponse } from "next/server";
import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
});

export async function POST(request) {
  try {
    const { bookingIds, userId, amount, currency, description } =
      await request.json();

    if (!bookingIds || !Array.isArray(bookingIds) || bookingIds.length === 0) {
      return NextResponse.json(
        { error: "Missing booking IDs" },
        { status: 400 }
      );
    }
    if (!userId || !amount || !currency || !description) {
      return NextResponse.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const session = await stripe.checkout.sessions.create({
      payment_method_types: ["card"],
      line_items: [
        {
          price_data: {
            currency: currency.toLowerCase(),
            product_data: { name: description },
            unit_amount: Math.round(amount * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      success_url: `${request.headers.get(
        "origin"
      )}/players/reservations?success=true&bookingIds=${encodeURIComponent(
        JSON.stringify(bookingIds)
      )}&totalCost=${amount}`,
      cancel_url: `${request.headers.get(
        "origin"
      )}/players/reservations?success=false`,
      metadata: {
        bookingIds: JSON.stringify(bookingIds),
        userId,
        totalCost: amount.toString(),
      },
    });

    return NextResponse.json({ sessionId: session.id, url: session.url });
  } catch (error) {
    console.error("Stripe Checkout Error:", error.message);
    return NextResponse.json(
      { error: "Failed to create Stripe session" },
      { status: 500 }
    );
  }
}
