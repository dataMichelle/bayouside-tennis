import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";
import { ObjectId } from "mongodb";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const playerId = searchParams.get("playerId");

  if (!playerId) {
    return NextResponse.json({ error: "Missing playerId" }, { status: 400 });
  }

  try {
    const client = await clientPromise;
    const db = client.db("bayou-side-tennis");
    const bookings = await db
      .collection("bookings")
      .find({ playerId })
      .sort({ startTime: 1 })
      .toArray();

    return NextResponse.json({ bookings });
  } catch (error) {
    return NextResponse.json(
      { error: error.message || "Failed to fetch reservations" },
      { status: 500 }
    );
  }
}
