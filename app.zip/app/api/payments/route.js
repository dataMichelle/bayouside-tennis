// app/api/payments/route.js

import { NextResponse } from "next/server";
import clientPromise from "@/lib/mongodb";
import { ObjectId } from "mongodb";

export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const bookingIds = searchParams.getAll("bookingId");

    console.log("GET /api/payments called:", { bookingIds });

    const client = await clientPromise;
    const db = client.db("bayou-side-tennis");

    if (bookingIds.length > 0) {
      const objectIds = bookingIds.map((id) => new ObjectId(id));
      const payments = await db
        .collection("payments")
        .find({ bookingId: { $in: objectIds } })
        .toArray();

      return NextResponse.json(payments, { status: 200 });
    } else {
      const payments = await db.collection("payments").find().toArray();
      return NextResponse.json(payments, { status: 200 });
    }
  } catch (error) {
    console.error("Error fetching payments:", {
      message: error.message,
      stack: error.stack,
    });
    return NextResponse.json(
      { error: "Failed to fetch payments" },
      { status: 500 }
    );
  }
}
